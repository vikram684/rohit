<section>
    <!--Navbar -->
    <nav class="mb-1 fixed-top navbar navbar-expand-lg navbar-dark danger-color">
        <a class="navbar-brand nav_bar_brand" href="#">Learn Things</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-3"
            aria-controls="navbarSupportedContent-3" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent-3">
            <ul class="navbar-nav ml-auto nav-list-item nav_align">
                <li class="nav-item">
                    <a class="nav-link waves-effect waves-light" href="/learnthings">Home
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link waves-effect waves-light" href="courses.php">Courses</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link waves-effect waves-light" href="shop.php">Shop</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link waves-effect waves-light" href="blog.php">Blog</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link waves-effect waves-light" href="about.php">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link waves-effect waves-light" href="contact.php">Contact</a>
                </li>
            </ul>

            <ul class="navbar-nav ml-auto nav-flex-icons social-icon-nav nav_align">
                <li class="nav-item">
                    <a class="nav-link waves-effect waves-light" href="https://twitter.com/learnthings_in">
                        <i class="fab fa-twitter"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link waves-effect waves-light" href="https://instagram.com/sagerohit">
                        <i class="fab fa-instagram"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link waves-effect waves-light" href="https://www.facebook.com/grabthings">
                        <i class="fab fa-facebook"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link waves-effect waves-light" href="https://www.linkedin.com/company/42897732">
                        <i class="fab fa-linkedin"></i>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    <!--/.Navbar -->
</section>