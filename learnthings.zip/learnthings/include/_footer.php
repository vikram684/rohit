<footer class="footer ">
    <div class="container bottom_border">
        <div class="row">
            <div class=" col-sm-4 col-md col-sm-4  col-12 col">
                <h5 class="headin5_amrc col_white_amrc pt2">About us</h5>
                <!--headin5_amrc-->
                <p class="mb10">Learn Things is a educational blog. We are writing meaningful content which will help
                    you to increase your knowledge.</p>
                <p><i class="fa fa-location-arrow"></i>Agarwal Farm, Mansarovar, Jaipur </p>
                <p><i class="fa fa-phone"></i> +91-7691094380 </p>
                <p><i class="fa fa fa-envelope"></i> Contact@learnthings.in </p>


            </div>


            <div class=" col-sm-4 col-md  col-6 col">
                <h5 class="headin5_amrc col_white_amrc pt2">Best Courses</h5>
                <!--headin5_amrc-->
                <ul class="footer_ul_amrc">
                    <li><a href="#">Website Design</a></li>
                    <li><a href="#">Python Mastery</a></li>
                    <li><a href="#">personality Development</a></li>
                    <li><a href="#">Digital Marketing</a></li>
                    <li><a href="#">English Speaking</a></li>
                    <li><a href="#">Content writing</a></li>
                </ul>
                <!--footer_ul_amrc ends here-->
            </div>


            <div class=" col-sm-4 col-md  col-6 col">
                <h5 class="headin5_amrc col_white_amrc pt2">Best Products</h5>
                <!--headin5_amrc-->
                <ul class="footer_ul_amrc">
                    <li><a href="#">Laptop for codding</a></li>
                    <li><a href="#">Free SEO Tools</a></li>
                    <li><a href="#">Keyboards and mouse#
                    <li><a href="#">High Speed router</a></li>
                    <li><a href="#">Office setup tools</a></li>
                    <li><a href="#">Best Books</a></li>
                </ul>
                <!--footer_ul_amrc ends here-->

            </div>


            <div class=" col-sm-4 col-md  col-12 col">
                <h5 class="headin5_amrc col_white_amrc pt2">Join our Newsletter</h5>
                <!--headin5_amrc ends here-->

                <form>
                    <div class="form-group">
                        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                            placeholder="Enter email">
                    </div>
                    <button type="submit" class="btn btn-danger">Subscribe</button>
                </form>
                <!--footer_ul2_amrc ends here-->

            </div>
        </div>
    </div>
    <div class="container">
        <ul class="foote_bottom_ul_amrc">
            <li><a href="#">Home</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Shop</a></li>
            <li><a href="#">Blog</a></li>
            <li><a href="#">Contact</a></li>
            <li><a href="#">Career</a></li>
        </ul>
        <!--foote_bottom_ul_amrc ends here-->

        <p class="text-center">Copyright @2019 | All Right Reserved <a href="learnthings.in">Learn Things</a></p>

        <ul class="social_footer_ul">
            <li><a href="https://www.facebook.com/grabthings"><i class="fab fa-facebook-f"></i></a></li>
            <li><a href="https://twitter.com/learnthings_in"><i class="fab fa-twitter"></i></a></li>
            <li><a href="https://www.linkedin.com/company/42897732"><i class="fab fa-linkedin"></i></a></li>
            <li><a href="https://instagram.com/sagerohit"><i class="fab fa-instagram"></i></a></li>
        </ul>
        <!--social_footer_ul ends here-->
    </div>
</footer>